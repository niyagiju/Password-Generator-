# Password Generator (Python)

A small, secure password generator written in Python. It includes a CLI script and an optional tiny GUI.

## Features
- Generates secure passwords using `secrets` and `string` modules.
- Configurable: length, include/exclude uppercase, lowercase, digits, and symbols.
- Generate multiple passwords at once and save to a file.
- Optional simple GUI (Tkinter) for single-password generation.

## Files
- `password_generator.py` - CLI script (main).
- `gui.py` - optional small Tkinter GUI (requires a desktop environment).
- `README.md` - this file.

## Usage (CLI)
```bash
# generate one 12-char password
python3 password_generator.py --length 12

# generate five 20-char passwords, no symbols
python3 password_generator.py -l 20 -n 5 --no-symbols

# save 10 passwords to a file
python3 password_generator.py -l 16 -n 10 -o my-passwords.txt
```

## GUI (optional)
```bash
python3 gui.py
```

## Requirements
- Python 3.7+ (no external packages required)
- For GUI: a desktop environment with Tkinter available (usually included with Python on most platforms).

## How to add to GitHub
1. Create a new repository on GitHub.
2. Copy these files into your project folder.
3. Commit and push:
```bash
git init
git add .
git commit -m "Initial commit - Password Generator in Python"
git branch -M main
git remote add origin https://github.com/yourusername/password-generator-python.git
git push -u origin main
```

Enjoy!